/*
 * Owen Rabe
 * Mar 29 23
 * Lots of bots unit 3 summative assignment
 */
package rabelotsofbots;


public class RabeLotsOfBots {

    
    public static void main(String[] args) {
        
    }
    
}
