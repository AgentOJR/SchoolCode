/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rabelotsofbots;

import TurtleGraphics.StandardPen;
import java.text.DecimalFormat;

/**
 *
 * @author owenrabe
 */
abstract public class AbstractRobot implements Robot {
    private final decimalFormat money = new DecimalFormat("#,##$0.00");
    protected int x,y,energy;
    protected double weight, cost;
    protected String powerSource, movementType,sensorType;
    final private static double MIN_WEIGHT = 10;
    final private static double MAX_WEIGHT = 100;
    final private static double MIN_COST = 100;
    final private static double MAX_COST = 1000;
    final private static int MIN_ENERGY = 0;
    final private static int MAX_ENERGY = 100;
    private static int NUM_ROBOTS = 0;
    /**
     * Default constructor to set all attributes to defaults, increment num robots counter.
     */
    public AbstractRobot(){
        x = 0;
        y = 0;
        energy = 100;
        weight  = 50;
        cost = 399.99;
        powerSource = "Battery";
        movementType = "Wheels";
        sensorType = "Infared";
        NUM_ROBOTS +=1;
        
    }
    /**
     * Constructor with specified x and y location
     * @param x the desired x location
     * @param y the desired y location
     */
    public AbstractRobot(int x, int y){
        this();
        this.x = x;
        this.y = y;
    }
    /**
     * constructor with specified xLoc, yLoc, weight and cost, sets all other attributes to defaults via chaining
     * @param x specified x loc
     * @param y specified y loc
     * @param weight specified weight
     * @param cost specified height
     */
    public AbstractRobot(int x, int y, double weight, double cost){
        this(x,y);
        this.weight = weight;
        this.cost = cost;
    }
    /**
     constructor with specified xLoc, yLoc, weight cost,power source, sensor type and movement type. sets all other attributes to defaults via chaining
     * @param x specified x loc
     * @param y specified y loc
     * @param weight specified weight
     * @param cost specified height
     * @param powerSource specified power source
     * @param movementType specified movement type
     * @param sensorType specified sensor type
     */
    public AbstractRobot(int x, int y, double weight, double cost, String powerSource, String movementType, String sensorType){
        this(x,y,weight,cost);
        this.powerSource = powerSource;
        this.movementType = movementType;
        this.sensorType = sensorType;
    }
    /**
     * moves the robot to a desired location
     * @param x desired x loc
     * @param y desired y loc
     */
    public void move(int x, int y){
        this.x = x;
        this.y = y;
    }
    /**
     * returns the current x pos of the robot
     * @return current x pos
     */
    public int getXPos(){
        return x;
    }
    /**
     * returns the current y pos of the robot
     * @return current y pos
     */
    public int getYPos(){
        return y;
    }
    /**
     * returns the weight of the robot
     * @return the weight
     */
    public double getWeight(){
        return weight;
    }
    /**
     * sets the weight of the robot to a desired value if it meets certain criteria
     * @param weight the desired weight
     * @return if the weight was set or not
     */
    public boolean setWeight(double weight){
        //if weight meets min and max criteria
        if(weight > MIN_WEIGHT && weight < MAX_WEIGHT){
            this.weight = weight;
            return true;
        }
        return false;
    }
    /**
     * get the cost of the robot
     * @return the cost
     */
    public double getCost(){
        return cost;
    }
    /**
     * Sets the cost of the robot to s specified value if it meets certain parameters
     * @param cost the desired cost
     * @return if the cost was set successfully or not
     */
    public boolean setCost(double cost){
        //if the cost is within the min and max thresholds
        if(cost > MIN_COST && cost <MAX_COST){
            this.cost = cost;
            return true;
        }
        return false;
    }
    /**
     * get the power source of the robot
     * @return the name of the power source
     */
    public String getPowerSource(){
        return powerSource;
    }
    /**
     * get the current energy level of the robot
     * @return the current energy level
     */
    public int getEnergy(){
        return energy;
        
    }
    /**
     * sets the energy of the robot to a desired value if it is within the parameters
     * @param energy the desired energy level
     * @return if the energy was set or not
     */
    public boolean setEnergy(int energy){
        //if the energy is within the bounds
        if(energy > MIN_ENERGY && energy < MAX_ENERGY){
            this.energy = energy;
            return true;
        }return false;
    }
    public String getMovementType(){
        return movementType;
    }
    public String getSensorType(){
        return sensorType;
    }
    public void setSensorType(String sensorType){
        this.sensorType = sensorType;
    }
    abstract public void draw(StandardPen p);
    public String toString(){
        return "ROBOT SUMMARY:\nxPos: " + x + "\nyPos: " + y + "\nWeight: " + weight + "\nCost: " + money.format(cost) + "\nWeight: " + weight + "kg\nMovement Type: " + movementType + "\nSensorType: ";
    }
}
