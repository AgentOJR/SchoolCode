
package simpleballmovement;

import java.awt.Graphics2D;


public class Ball {
    public int radius;
    public int xPos;
    public int yPos;
    private static double PI = 3.14;
    private boolean flippedX = false,flippedY = false;
    
    public Ball(){
        xPos = 0;
        yPos = 0;
        radius = 100;
        
    }
    public Ball(int radius){
        this();
        this.radius = radius;
    }
    public Ball(int xPos,int yPos,int radius){
        this(radius);
        this.xPos = xPos;
        this.yPos = yPos;
    }
    public void move(){
        if(xPos == 280){
            flippedX = true;
        }else if (xPos == 0){
            flippedX = false;
        }
        if(yPos == 155){
            flippedY = true;
        }else if(yPos == 0){
            flippedY = false;
        }
        if(!flippedX){
            xPos++;
        }else{
            xPos--;
        }
        if(!flippedY){
            yPos++;
        }
        else{
            yPos--;
        }
        
        
        
        
    }
    public void draw(Graphics2D g2d){
        g2d.fillOval(xPos, yPos, radius, radius);
    }
        
}
