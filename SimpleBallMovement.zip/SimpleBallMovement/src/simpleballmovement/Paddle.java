
package simpleballmovement;


public class Paddle {
    int x;
    int y;
    boolean moving;
    final static int LENGTH = 30;
    final static int WIDTH = 5;
    public Paddle(){
        x = 0;
        y = 0;
    }
    public Paddle(int x,int y){
        this.x = x;
        this.y = y;
    }
    public void up(){
//        if(moving){
//            moving = false;
//        }
        y++;
//        moving = true;
        
    }
    public void down(){
//        if(moving){
//            moving = false;
//        }
        y--;
        
    }
    
}
