    /*
 * B Cutten
    May 2022
    This is a high level window to which a panel will be added
 */
package simpleballmovement;

import java.awt.EventQueue;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;


public class SimpleBallMovement extends JFrame implements KeyListener {

    //constructor
    public SimpleBallMovement() {
        //create the User interface
        initUI();
        this.addKeyListener(this);
        this.setFocusable(true);
        this.requestFocus();
    }

    //create the custom JFrame
    private void initUI() {        
        //set title of the JFrame
        setTitle("Simple Ball Movement");
        //add a custom JPanel to draw on
        add(new DrawingSurface());
        //set the size of the window
        setSize(300, 200);
        //tell the JFrame what to do when closed
        //this is important if our application has multiple windows
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        
        
    }
    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("e");
        if(e.getKeyChar()==(("w").charAt(0))){
            System.out.println("1");
        }
    }

    public static void main(String[] args) {        
        //makes sure that GUI updates nicely with the rest of the OS
        EventQueue.invokeLater(() -> {
            JFrame ex = new SimpleBallMovement();
            ex.setVisible(true);
        });
    }

    @Override
    public void keyTyped(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
