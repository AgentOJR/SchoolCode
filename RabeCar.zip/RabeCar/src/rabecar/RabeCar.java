/*
 * Owen Rabe
 * Mar 6 2023
 * Drawing a car using classes
 */
package rabecar;


public class RabeCar {

    
    public static void main(String[] args) {
        Car c = new Car();
        c.draw();
    }
    
}
