/*
 * Owen Rabe
 * Mar 8 23
 * Making a basketball simulator (Test harness for Player and team Classes)
 */
package rabebasketball4u;

import java.io.File;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class RabeBasketball4U {
private static Team[] teams;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        readFile();
        mainMenu();
        
    }

    /**
     * a method to read from a data file and create an array of team objects
     * from it
     *
     * @return an array with all of the team objects stored in it
     */
    public static void readFile() {
        File f = new File("src/RabeBasketball4U/ball.4u");
        int dunk;
        int threes;
        int def;
        int speed;

        String pName;
        String tName;
        int wins;
        int loss;
        Player[] players = new Player[5];
        try {
            Scanner s = new Scanner(f);
            int numTeams = Integer.parseInt(s.nextLine());
            teams = new Team[numTeams];
            for (int i = 0; i < numTeams; i++) {
                tName = s.nextLine();
                wins = Integer.parseInt(s.nextLine());
                loss = Integer.parseInt(s.nextLine());
                for (int j = 0; j < 5; j++) {
                    pName = s.nextLine();
                    speed = Integer.parseInt(s.nextLine());
                    threes = Integer.parseInt(s.nextLine());
                    dunk = Integer.parseInt(s.nextLine());
                    def = Integer.parseInt(s.nextLine());
                    players[j] = new Player(pName, speed, threes, dunk, def);
                }
                teams[i] = new Team(tName, players, wins, loss);
            }
            
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }

        
    }

    public static void mainMenu() {
        String choice = "";
        showMsg("Welcome to BasketBall4U!");
        boolean goodInput = false;
        while (!goodInput) {

            choice = getInput("What would you like to do?\n1. View Team menu"
                    + "\n2. View player menu\n"
                    + "or type \"-1\" to exit.");
            if ((choice .equals(0) && choice.equals(3)) || choice.equalsIgnoreCase("q")) {
                goodInput = true;
            } else {
                showMsg("I didn't understand that input, please try again...");
            }
        }
        if(choice.equals(1)){
            teamMenu();
        }else if(choice.equals(2)){
            playerMenu();
        }else{
            showMsg("Later gator!");
        }
    }

    public static void showMsg(String msg) {
        JOptionPane.showMessageDialog(null, msg);
    }

    public static String getInput(String msg) {
        boolean running = true;
        String input = "";
        while (running) {
            try {
                input = (JOptionPane.showInputDialog(msg));
                running = false;
            } catch (Exception e) {
                showMsg("Error: " + e);
            }
        }
        return input;
    }
    public static void teamMenu(){
        String teamMenuTxt = "Teams in the league: \n\n";
        String input;
        for (int i = 0; i < teams.length; i++) {
            teamMenuTxt+=("-" + teams[i].getName() + "\n");
        }
        teamMenuTxt += "\n1. View team\n2. Simulate game\nOr type \"b\" to go back.";
        input = getInput(teamMenuTxt);
        
    }
    public static void playerMenu(){
        
    }
}
