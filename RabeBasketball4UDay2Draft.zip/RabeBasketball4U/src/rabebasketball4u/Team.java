/*
 * Owen rabe
 * Mar 7 23
 * A team class for a basketball simulator, dependancies in Player class
 */
package rabebasketball4u;

import javax.swing.JOptionPane;

public class Team {

    private String name;
    private int wins;
    private int losses;
    private Player[] players = new Player[5];

    public Team(String name, Player[] players) {
        this.name = name;
        this.players = players;
        wins = 0;
        losses = 0;

    }

    public Team(String name, Player[] players, int wins, int losses) {
        this(name, players);
        this.wins = wins;
        this.losses = losses;
    }

    public String getName() {
        return name;
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }

    public Player getPlayer(int choice) {
        

        return players[choice - 1];
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public void setLosses(int losses) {
        this.losses = losses;
    }

    public void setPlayer(Player player, int choice) {
        players[choice - 1] = player;
    }

    public String toString() {
        String msg = "";
        msg += name + "\n";
        for (int i = 0; i < 5; i++) {
            msg += players[i].getName();
        }

        return msg;
    }

    public int getScore() {
        int factor = 0;
        for (int i = 0; i < 5; i++) {
            factor += players[i].getSpeed();
            factor += players[i].getThreePoint();
            factor += players[i].getDunk();
            factor += players[i].getDefence();
        }
        factor = factor / 4;
        return (int) (Math.random() * factor) + 75;
    }

    public int getPlayerIndex(String playerName) {
        for (int i = 0; i < 5; i++) {
            if (playerName.equalsIgnoreCase(players[i].getName())) {
                return i + 1;
            }

        }
        return -1;
    }

    public Player trade(Player other) {
int randPlayer = (int) (Math.random() * 5);
Player temp = new Player(players[randPlayer].getName(),players[randPlayer].getSpeed(),players[randPlayer].getThreePoint(),players[randPlayer].getDunk(),players[randPlayer].getDefence());
players[randPlayer] = other;
return players[randPlayer];

    }

}
