/*
 * Owen Rabe
 * Mar 7 23
 * A class for a player on a team in a basketball simulator
 */
package rabebasketball4u;


public class Player {
    String name;
private int speed;
private int threePoint;
private int dunk;
private int defence;

    public Player(String name){
        this.name = name;
        speed = (int) ((Math.random() * 11) + 0);
        threePoint = (int) ((Math.random() * 11) + 0);
        dunk = (int) ((Math.random() * 11) + 0);
        defence = (int) ((Math.random() * 11) + 0);
    }
    public Player(String name,int speed, int threePoint, int dunk, int defence){
        this(name);
        this.speed = speed;
        this.threePoint = threePoint;
        this.dunk = dunk;
        this.defence = defence;
    }
    //getters
    public String getName(){
        return name;
    }
    public int getSpeed(){
        return speed;
    }
    public int getThreePoint(){
        return threePoint;
    }
    public int getDunk(){
        return dunk;
    }
    public int getDefence(){
        return defence;
    }
    //setters
    public void setName(String name){
        this.name  = name;
    }
    public void setSpeed(int speed){
        this.speed = speed;
    }
    public void setThreePoint(int threePoint){
        this.threePoint = threePoint;
    }
    public void setDunk(int dunk){
        this.dunk = dunk;
    }
    public void setDefence(int defence){
        this.defence  = defence;
    }
    //tostring
    public String toString(){
        return (name + "\n" + speed + "/10\n" + threePoint + "/10\n" + dunk + "/10\n" + defence + "/10");
    }
}
