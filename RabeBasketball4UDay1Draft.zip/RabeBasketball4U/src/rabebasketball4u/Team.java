/*
 * Owen rabe
 * Mar 7 23
 * A team class for a basketball simulator, dependancies in Player class
 */
package rabebasketball4u;

import javax.swing.JOptionPane;

public class Team {

    private String name;
    private int wins;
    private int losses;
    private Player[] players = new Player[5];
public Team(String name, Player[] players){
    this.name = name;
    this.players = players;
    wins = 0;
    losses = 0;
    
}
public Team(String name, Player[] players, int wins, int losses){
    this(name, players);
    this.wins = wins;
    this.losses = losses;
}
public String getName(){
    return name;
}
public int getWins(){
    return wins;
}
public int getLosses(){
    return losses;
}
public Player getPlayer(){
    String[] names = new String[5];
    for (int i = 0; i < 5; i++) {
        names[i] = players[i].getName();
    }
    boolean goodInput = false;
    int choice = 0;
    while(!goodInput){
    try {
        choice = Integer.parseInt(JOptionPane.showInputDialog("Which player do you want?\n1. " + names[0] + "\n2. " + names[1]+ "\n3. " + names[2]+ "\n4. " + names[3]+ "\n5. " + names[4]));
        goodInput = true;
    }
    catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Sorry, I don't understand that input, please try again...");
    }}
    return players[choice - 1];
}
public void setName(String name){
    this.name = name;
}
public void setWins(int wins){
    this.wins  = wins;
}
public void setLosses(int losses){
    this.losses = losses;
}

public void setPlayer (Player player, int choice){
    players[choice] = player;
}
public String toString(){
    String msg = "";
    msg+= name + "\n";
}
public int getScore(){
    
}
public int getPlayerIndex(String playerName){
    
}
public Player trade(Player other){
    
}

}
