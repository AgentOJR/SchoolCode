/*
 * Owen Rabe
 * Mar 8 23
 * Making a basketball simulator (Test harness for Player and team Classes)
 */
package rabebasketball4u;

import java.io.File;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class RabeBasketball4U {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Team[] teams;
        teams = readFile();
        mainMenu(teams);

    }

    /**
     * a method to read from a data file and create an array of team objects
     * from it
     *
     * @return an array with all of the team objects stored in it
     */
    public static Team[] readFile() {
        File f = new File("src/RabeBasketball4U/ball.4u");
        int dunk;
        int threes;
        int def;
        int speed;

        String pName;
        String tName;
        int wins;
        int loss;
        Player[] players = new Player[5];
        try {
            Scanner s = new Scanner(f);
            int numTeams = Integer.parseInt(s.nextLine());
            Team[] teams = new Team[numTeams];
            for (int i = 0; i < numTeams; i++) {
                tName = s.nextLine();
                wins = Integer.parseInt(s.nextLine());
                loss = Integer.parseInt(s.nextLine());
                for (int j = 0; j < 5; j++) {
                    pName = s.nextLine();
                    speed = Integer.parseInt(s.nextLine());
                    threes = Integer.parseInt(s.nextLine());
                    dunk = Integer.parseInt(s.nextLine());
                    def = Integer.parseInt(s.nextLine());
                    players[j] = new Player(pName, speed, threes, dunk, def);
                }
                teams[i] = new Team(tName, players, wins, loss);
            }
            return teams;
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
        return null;

    }

    public static void mainMenu(Team[] teams) {
        String choice = "";
        showMsg("Welcome to BasketBall4U!");
        boolean goodInput = false;
        boolean running = true;
        while (running) {
            goodInput = false;
            while (!goodInput) {

                choice = getInput("What would you like to do?\n1. View Team menu"
                        + "\n2. View player menu\n"
                        + "or type \"-1\" to exit.");
                if ((choice.equalsIgnoreCase("1") || choice.equalsIgnoreCase("2")) || choice.equalsIgnoreCase("q")) {
                    goodInput = true;

                } else {
                    showMsg("I didn't understand that input, please try again...");
                }
            }
            if (choice.equalsIgnoreCase("1")) {
                teamMenu(teams);
            } else if (choice.equalsIgnoreCase("2")) {
                playerMenu(teams);
            } else {
                showMsg("Later gator!");
                running = false;
            }
        }
    }

    public static void showMsg(String msg) {
        JOptionPane.showMessageDialog(null, msg);
    }

    public static String getInput(String msg) {
        boolean running = true;
        String input = "";
        while (running) {
            try {
                input = (JOptionPane.showInputDialog(msg));
                running = false;
            } catch (Exception e) {
                showMsg("Error: " + e);
            }
        }
        return input;
    }

    public static void teamMenu(Team[] teams) {
        String teamMenuTxt = "Teams in the league: \n\n";
        String input = "";
        boolean goodInput = false;
        boolean running = true;
        while (running) {
            goodInput = false;
            teamMenuTxt = "Teams in the league: \n\n";
            for (int i = 0; i < teams.length; i++) {
                teamMenuTxt += ("-" + teams[i].getName() + "\n");
            }
            teamMenuTxt += "\n1. View team\n2. Simulate game\nOr type \"b\" to go back.";
            while (!goodInput) {
                input = getInput(teamMenuTxt);
                if (input.equalsIgnoreCase("1") || input.equalsIgnoreCase("2") || input.equalsIgnoreCase("b")) {
                    goodInput = true;
                }
            }
            if (input.equalsIgnoreCase("1")) {
                viewTeam(teams);
            } else if (input.equalsIgnoreCase("2")) {
                simGame(teams);
            } else if (input.equalsIgnoreCase("b")) {
                running = false;
            }
        }
    }

    public static void playerMenu(Team[] teams) {

    }

    public static void simGame(Team[] teams) {
        Team team1;
        Team team2;
        String input;
        String msg;
        int score1 = 0;
        int score2 = 0;
        int choice = -1;
        msg = "Select a team\n";
        for (int i = 0; i < teams.length; i++) {
            msg+="-" + teams[i].getName() + "\n";
        }
        boolean goodInput = false;
        while(!goodInput){
            input  = getInput(msg);
            for (int i = 0; i < teams.length; i++) {
                if(input.equalsIgnoreCase(teams[i].getName())){
                    goodInput = true;
                    choice = i;
                }
                
            }
            if(!goodInput){
                showMsg("Sorry, team \"" + input +"\" not found. Try again");
            }
        }
        team1 = teams[choice];
        //for second team
        goodInput = false;
        while(!goodInput){
            input  = getInput(msg);
            for (int i = 0; i < teams.length; i++) {
                if(input.equalsIgnoreCase(teams[i].getName())){
                    goodInput = true;
                    choice = i;
                }
                
            }
            if(!goodInput){
                showMsg("Sorry, team \"" + input +"\" not found. Try again");
            }
        }
        team2 = teams[choice];
        showMsg("Ready to sim?\n" + team1.getName() + " - W: "  + team1.getWins() + " - L: " + team1.getLosses() + 
                "\n\n  *****VS*****\n\n" + team2.getName() + " - W: "  + team2.getWins() + " - L: " + team2.getLosses() );
        boolean noTie = false;
        while(!noTie){
        score1 = team1.getScore();
        score2 = team2.getScore();
        if(score1>score2 || score2> score1){
            noTie = true;
        }}
        if(score1>score2){
            team1.addWins();
            team2.addLoss();
        }else{
            team2.addWins();
            team1.addLoss();
        }
    }

    public static void viewTeam(Team[] teams) {
        boolean running = true;
        String msg = "Teams in the league:\n\n";
        String choice = "";
        int name = -1;
        boolean goodInput = false;
        for (int i = 0; i < teams.length; i++) {
            msg += ("-" + teams[i].getName() + "\n");
        }
        msg += "\nOr type \"b\" to go back";
        while (running) {

            while (!goodInput) {
                choice = getInput(msg);
                for (int i = 0; i < teams.length; i++) {
                    if (choice.equalsIgnoreCase(teams[i].getName())) {
                        goodInput = true;
                        name = i;
                    }

                }
                if (choice.equalsIgnoreCase("b")) {
                    goodInput = true;
                    running = false;
                } else if (!goodInput) {
                    showMsg("I couldn't find \"" + choice + "\", please try again...");
                    choice = "";

                }
            }
            if (name != -1) {
                showMsg(teams[name].toString());
                goodInput = false;
                name = -1;

            } if(choice.equalsIgnoreCase("b")) {
                running = false;

            }
        }

    }
}
